package application.rest.v1.category;

import application.rest.v1.vendor.Vendor;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class CategoryVO {

    private Vendor vendor;

    @JsonProperty("categories")
    Map<Long, SubCategoryVO> subCategoryVOMap = new TreeMap<>();

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    public Map<Long, SubCategoryVO> getSubCategoryVOMap() {
        return subCategoryVOMap;
    }

    public void setSubCategoryVOMap(Map<Long, SubCategoryVO> subCategoryVOMap) {
        this.subCategoryVOMap = subCategoryVOMap;
    }
}
