package application.rest.v1.category;

import application.rest.v1.product.Product;
import application.rest.v1.product.ProductService;
import application.rest.v1.vendor.Vendor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Service
public class CategoryService {

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    ProductService productService;

    public Category addCategory(Category category) throws Exception {
        if(category.getParent()!=null) {
            Category parentCat = categoryRepository.findById(category.getParent()).orElse(null);
            if(parentCat.getHasSubCategory() == 0) {
                throw new Exception("Cannot create SubCategory. You can only add Products under this category.");
            }
        }
        Category prodResp = categoryRepository.save(category);
        return prodResp;
    }

    public Category updateCategory(Category category) throws Exception {
        Category categoryResp = null;
        Category cat = getCategory(category.getChild());
        category.setParent(cat.getParent());
        category.setVendor(cat.getVendor());
        if(cat!=null && cat.getHasSubCategory()!=category.getHasSubCategory()) {
            List<Category> childCat = findByParent(category.getChild());
            List<Product> productsByCategory = productService.getProductsByCategory(category.getChild());
            if(childCat.size() > 0 ) {
                throw new Exception("Cannot change SubCategory flag. Remove the sub categories and then update.");
            } else if(productsByCategory.size() > 0) {
                throw new Exception("Cannot change SubCategory flag. Remove all the products under this category.");
            } else {
                categoryResp = categoryRepository.save(category);
            }
        } else {
            categoryResp = categoryRepository.save(category);
        }
        return categoryResp;
    }

    public Category getCategory(Long id) {
        return categoryRepository.findById(id).orElse(null);
    }

    public CategoryVO getCategoryByVendor(Long vendorId) {
        CategoryVO categoryVO = new CategoryVO();
        List<SubCategoryVO> categoryVOList = new ArrayList<>();
        Vendor vendor = new Vendor(vendorId);
        List<Category> categories = new ArrayList<>();
        categoryRepository.findByVendor(vendor).forEach(categories::add);

        categories.forEach(category -> {
            if(categoryVO.getVendor()==null) {
                categoryVO.setVendor(category.getVendor());
            }
            SubCategoryVO subCategoryVO = new SubCategoryVO();
            subCategoryVO.setChild(category.getChild());
            subCategoryVO.setHasSubCategory(category.getHasSubCategory());
            subCategoryVO.setName(category.getName());
            subCategoryVO.setParent(category.getParent());
            categoryVOList.add(subCategoryVO);
        });

        Map<Long,SubCategoryVO> subCategoryMap = new TreeMap<Long, SubCategoryVO>();
        for(SubCategoryVO subCategoryVO : categoryVOList) {
            if(subCategoryVO.getParent()==null) {
                subCategoryMap.put(subCategoryVO.getChild(), subCategoryVO);
            } else {
                searchAndPut(subCategoryMap, subCategoryVO);
            }
        }
        categoryVO.setSubCategoryVOMap(subCategoryMap);
        return categoryVO;
    }

    private void searchAndPut(Map<Long, SubCategoryVO> subCategoryMap, SubCategoryVO subCategoryVO) {
        SubCategoryVO subCategory = subCategoryMap.get(subCategoryVO.getParent());
        if(subCategoryMap.containsKey(subCategoryVO.getParent())) {
            subCategory.getCategories().put(subCategoryVO.getChild(), subCategoryVO);
            return;
        } else {
            searchAndPut(subCategory.getCategories(), subCategoryVO);
        }
    }

    public void deleteCategory(Long id) throws Exception {
        Category categoryResp = null;
        Category category = getCategory(id);
        if (category == null) {
            throw new Exception("This Category does not exist.");
        }
        List<Category> categoryList = findByParent(id);
        List<Product> productsByCategory = productService.getProductsByCategory(id);
        if (categoryList.size() > 0) {
            throw new Exception("Cannot delete. Remove all the sub categories and then try.");
        } else if (productsByCategory.size() > 0) {
            throw new Exception("Cannot delete. Remove all the products under this category and then try.");
        }
        categoryRepository.deleteById(id);
    }

    private List<Category> findByParent(Long child) {
        List<Category> categoryList = new ArrayList<>();
        categoryRepository.findByParent(child).forEach(categoryList::add);
        return categoryList;
    }

    /*
    public List<Category> getCategoryById(Long id) {
        List<Category> categories = new ArrayList<>();
        categoryRepository.findAll().forEach(categories::add);
        return categories;
    }

    public List<Category> getProdByNameAndZipCode(String name, String zipcode) {
        List<Category> categories = new ArrayList<>();
        categoryRepository.findByNameIgnoreCaseContaining(name).forEach(categories::add);
        return categories;
    }*/
}
