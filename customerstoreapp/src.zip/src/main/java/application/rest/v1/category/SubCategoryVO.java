package application.rest.v1.category;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class SubCategoryVO {

    private Long child;
    private Long parent;
    private String name;
    private int hasSubCategory;

    private Map<Long, SubCategoryVO> categories = new TreeMap<Long, SubCategoryVO>();

    public Map<Long, SubCategoryVO> getCategories() {
        return categories;
    }

    public void setCategories(Map<Long, SubCategoryVO> categories) {
        this.categories = categories;
    }

    public Long getChild() {
        return child;
    }

    public void setChild(Long child) {
        this.child = child;
    }

    public Long getParent() {
        return parent;
    }

    public void setParent(Long parent) {
        this.parent = parent;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHasSubCategory() {
        return hasSubCategory;
    }

    public void setHasSubCategory(int hasSubCategory) {
        this.hasSubCategory = hasSubCategory;
    }
}
